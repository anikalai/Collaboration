package com.jpro.studentsmeetbackend.dao;

public interface FriendDAO {

}
