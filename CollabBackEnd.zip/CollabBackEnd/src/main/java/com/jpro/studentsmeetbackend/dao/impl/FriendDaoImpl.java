package com.jpro.studentsmeetbackend.dao.impl;

public class FriendDaoImpl {

}
