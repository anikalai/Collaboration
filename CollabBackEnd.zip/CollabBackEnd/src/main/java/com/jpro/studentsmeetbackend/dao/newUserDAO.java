package com.jpro.studentsmeetbackend.dao;

import java.util.List;

import com.jpro.studentsmeetbackend.model.User;

public interface newUserDAO {
	public boolean save(User user);

	public boolean update(User user);

	public User get(String id);

	public List<User> list();

	public User validate(String id, String password);
}
